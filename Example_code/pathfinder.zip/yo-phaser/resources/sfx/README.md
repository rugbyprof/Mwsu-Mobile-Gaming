Place sound effects in this folder, preferably files in a lossless format, and
convert them to an audio sprite using the following npm script:

```sh
$ npm run audiosprite:sfx
```
