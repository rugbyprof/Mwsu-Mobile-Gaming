
//====================================================================

var playState = {
    /** 
    * Establish eureca client and setup some globals
    */
    init: function(){
        //Add the server client for multiplayer
        this.client = new Eureca.Client();
        
        game.global.playerReady = false;

        game.global.dude = null;
        
        game.global.playerObjs = {};
        game.global.playerStates = {};

    },
    /**
    * Calls the dude's update method
    */
    update: function() {
    	if (!game.global.dude) 
    	    return;
    	    
        
        game.global.dude.update();


    },
    /**
    * Initialize the multiPlayer methods
    * and bind some keys to variables
    */
    create: function(){
        this.initMultiPlayer(game,game.global);
        
        this.upKey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        this.downKey = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
        this.leftKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        this.rightKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);
    },
    
    /**
    * Handles communication with the server
    */
    initMultiPlayer: function(game,globals){
        
        // Reference to our eureca so we can call functions back on the server
        var eurecaProxy;
        
        /**
        * Fires on initial connection
        */
        this.client.onConnect(function (connection) {
            console.log('Incoming connection');
            
        });
        /**
        * When the connection is established and ready
        * we will set a local variable to the "serverProxy" 
        * sent back by the server side.
        */
        this.client.ready(function (serverProxy) {
             // Local reference to the server proxy to be 
             // used in other methods within this module.
             eurecaProxy = serverProxy;

        });
        
        /**
        * This sets the players id that we get from the server
        * It creates the instance of the player, and communicates
        * it's state information to the server.
        */
        this.client.exports.setId = function(id,info){
            console.log("Setting Id:" + id,info);

            // Assign my new connection Id
            globals.myId = id;
            
            // Create new "dude"
            globals.dude = new player(id, info.order, game,eurecaProxy)
            
            state = globals.dude.getState();
            
            // Put instance of "dude" into list
            globals.playerStates[id] = globals.dude.getState();
            globals.playerObjs[id] = globals.dude
        
            console.log(state);
        
            //Send state to server
            //
            eurecaProxy.initPlayer(id,state);
        
            // debugging
            console.log(globals.playerStates);

            // Were ready to go
            globals.playerReady = true;
            
        }
        /**
        * Called from server when another player "disconnects"
        */
        this.client.exports.kill = function(id){	
            if (globals.playerStates[id]) {
                globals.playerObjs[id].kill();
                console.log('killing ', id, globals.playerObjs[id]);
            }
        }	
        /**
        * This is called from the server to spawn enemy's in the local game
        * instance.
        */
        this.client.exports.spawnEnemy = function(id, order, enemy_state){
            
            if (id == globals.myId){
                return; //this is me
            }

            console.log('Spawning New Player');
            
            globals.playerStates[id] = enemy_state;
            globals.playerObjs[id] = new player(id, order, game, eurecaProxy);
        
            
            
            //enemy.init()
            
            console.log(globals.playerStates);
            console.log(globals.playerObjs);

        }

        /**
        * This is called from the server to update a particular players
        * state. 
        */       
        this.client.exports.updateState = function(id,player_state){
            //console.log(id,player_state);
            
            // Don't do anything if its me
            if(globals.myId == id){
                return;
            }
            
            // If player exists, update that players state. 
            if (globals.playerStates[id])  {
                globals.playerStates[id] = player_state;
                globals.playerObjs[id].updateState(globals.playerStates[id]);
            }
            
            //now how do we update everyone??
         }
         
        
    },
    /**
    * Not used
    */
    render: function(){
       
    },
    /**
    * Not used, but could be called to go back to the menu.
    */
    startMenu: function() {
        game.state.start('menu');
    },
};

var player = function (index, order, game,proxyServer) {
    
    var x;                      // x coord
    var y;                      // y coord
    
    var player_id;
    
    var player_order;           // game join order (debugging)
    
    var alive;                  // player alive or dead
    var state;                  // state info about player
    var proxy;                  // reference to proxy server
    
    var tint;                   // player tint

    var upKey;                  //references to movement keys
    var downKey;
    var leftKey;
    var rightKey;

    var health;                 // player health 
    var startTime;              // starting game time     
 
	
    function init(index, order, game,proxyServer){
    
        player_id = index;
        
        player_order = order
    
        proxy = proxyServer;
    
        sprite = game.add.sprite(x, y, 'dude');
    
        upKey = game.input.keyboard.addKey(Phaser.Keyboard.UP);
        downKey = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
        leftKey = game.input.keyboard.addKey(Phaser.Keyboard.LEFT);
        rightKey = game.input.keyboard.addKey(Phaser.Keyboard.RIGHT);

        health = 30;
	    
        state = {};
        
        x = 0;
        y = 0;
        alive = true;
        tint = Math.random() * 0xffffff;
        sprite.tint = tint;
        sprite.id = index;
        
        state.alive = alive;
        state.tint = tint;
        state.x = 0;
        state.y = 0;
        
        startTime = game.time.time;
        
    };
    
    function updateState (state){
        tint = state.tint;
        sprite.x = state.x;
        sprite.y = state.y;
        alive = state.alive;
        health = state.health;
        
        if(game.time.time - startTime > 2000){
            console.log  
//             console.log(game.time.time);
//             for(s in state){
//                 console.log(state[s]);
//             }
            console.log(player_id);
            startTime = game.time.time;
        }
    };
    
    function getState(){
        return state;
    }

    function update() {
        state.tint = tint;
        state.x = sprite.x;
        state.y = sprite.y;
        state.alive = alive;
        state.health = health;
    
        // Send your own state to server on your update and let
        // it do whatever with it. 
        proxy.handleState(player_id,state);

        if (upKey.isDown)
        {
            sprite.y-=3;
        }
        else if (downKey.isDown)
        {
            sprite.y+=3;
        }

        if (leftKey.isDown)
        {
            sprite.x-=3;
        }
        else if (rightKey.isDown)
        {
            sprite.x+=3;
        } 
    
        old_x = sprite.x;
        old_y = sprite.y;
    };
    
    function render() {
        game.debug.text( "This is debug text", 100, 380 );
    };

    function kill() {
        alive = false;
        sprite.kill();
    };
    
    init(index, order, game,proxyServer);
    
    return {
        render : render,
        updateState : updateState,
        update : update,
        kill : kill,
        getState : getState
    };
};